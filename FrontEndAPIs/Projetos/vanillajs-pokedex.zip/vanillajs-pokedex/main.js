import { fetchPokemons } from './fetchApi.js'
import  { searchPoke } from './searchPokemon.js'

//await fetchPokemons(10)

searchPoke


